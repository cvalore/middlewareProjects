package com.oauth.resourceserver.resourceserver.service;

import com.oauth.resourceserver.resourceserver.model.Image;
import com.oauth.resourceserver.resourceserver.model.User;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.List;

public interface ImageService {

      List<Image> findByUserId(String uuid);

      Image findByImageId(String u_uuid, String i_uuid);

      Image saveImage(MultipartFile file, String u_uuid);

      void updateImage(String userUuid, String imageUuid, String newTitle);

      void deleteImageById(String u_uuid, String i_uuid);

      void deleteImagesByUser(String u_uuid);

      List<Image> findAllImages();

      void deleteAllImages(List<User> users);

      void addLinks(Image image, String u_uuid, HttpServletRequest req);

      InputStream findByImageIdRaw(String u_uuid, String i_uuid);
}
