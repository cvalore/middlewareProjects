package com.oauth.resourceserver.resourceserver.service;

import com.oauth.resourceserver.resourceserver.model.Database;
import com.oauth.resourceserver.resourceserver.model.ParameterStringBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

@Service("authService")
public class AuthServiceImpl implements AuthService {

      @Override
      public boolean checkToken(String accessToken, String clientId, String clientSecret) {

            String response = null;

            try {
                  Map<String, String> parameters = new HashMap<>();
                  parameters.put("access_token", accessToken);
                  parameters.put("client_id", clientId);
                  parameters.put("client_secret", clientSecret);

                  URL url = new URL(Database.CHECK_TOKEN_PATH);
                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                  conn.setRequestMethod("POST");
                  conn.setDoOutput(true);
                  DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                  out.writeBytes(ParameterStringBuilder.getParamsString(parameters));
                  out.flush();
                  out.close();

                  int status = conn.getResponseCode();

                  if(status != HttpStatus.OK.value()) {
                        return false;
                  }

                  //read response
                  BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                  String inputLine;
                  StringBuffer content = new StringBuffer();
                  while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                  }
                  in.close();

                  response = content.toString();

                  conn.disconnect();

            } catch (IOException e) {
                  e.printStackTrace();
                  return false;
            }

            System.out.println("RESP: " + response);

            return true;
      }
}
