package com.oauth.resourceserver.resourceserver.service;

import com.oauth.resourceserver.resourceserver.exceptions.DbConnectionException;
import com.oauth.resourceserver.resourceserver.model.Database;
import com.oauth.resourceserver.resourceserver.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service("userService")
public class UserServiceImpl implements UserService{

      private Connection conn = null;
      private Statement stmt = null;
      private String query = null;

      @Autowired
      private PasswordEncoder passwordEncoder;

      public List<User> findAllUsers() {
            List<User> users = new ArrayList<>();

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT * FROM Users;";
                  ResultSet res = stmt.executeQuery(query);
                  while(res.next()){
                        User newuser = new User(res.getString("uuid"), res.getString("name"));
                        newuser.addLink(res.getString("homeLink"), "home");
                        newuser.addLink(res.getString("selfLink"), "self");
                        newuser.addLink(res.getString("usersLink"), "users");
                        newuser.addLink(res.getString("imagesLink"), "images");
                        newuser.addUploadFolderLink(res.getString("uploadFolderLink"), "upload_folder");
                        users.add(newuser);
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            return users;
      }

      public User findById(String uuid) {
            User user = null;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT * FROM Users WHERE uuid = '" + uuid + "'";
                  ResultSet res = stmt.executeQuery(query);
                  while(res.next()){
                        user = new User(res.getString("uuid"), res.getString("name"));
                        user.addLink(res.getString("homeLink"), "home");
                        user.addLink(res.getString("selfLink"), "self");
                        user.addLink(res.getString("usersLink"), "users");
                        user.addLink(res.getString("imagesLink"), "images");
                        user.addUploadFolderLink(res.getString("uploadFolderLink"), "upload_folder");
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            return user;
      }

      public User saveUser(User user) {
            String uuid = UUID.randomUUID().toString().split("-")[0];
            user.setUuid(uuid);

            String password = passwordEncoder.encode(user.getPassword());
            user.setPassword(password);

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "INSERT INTO Users (uuid, name) VALUES ('" + uuid + "', '" + user.getName() + "')";
                  stmt.executeUpdate(query);

                  //INSERT INTO oauth_users(username, password, enabled) VALUES ('user', 'user', TRUE);
                  String query2 = "INSERT INTO oauth_users(username, password, enabled) VALUES ('" + user.getUuid() + "','" + password + "',TRUE)";
                  stmt.executeUpdate(query2);

                  //INSERT INTO oauth_user_authorities(username, authority) VALUES ('user', 'USER');
                  String query3 = "INSERT INTO oauth_user_authorities(username, authority) VALUES ('" + user.getUuid() + "','ROLE_USER')";
                  stmt.executeUpdate(query3);

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            return user;
      }

      public void updateUser(User newUser, User currentUser) {
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "UPDATE Users " +
                        "SET name = '" + newUser.getName() +"' WHERE uuid = '" + currentUser.getUuid() + "'";
                  stmt.executeUpdate(query);

                  if(newUser.getPassword() != null && !newUser.getPassword().isEmpty()) {
                        String newPassword = passwordEncoder.encode(newUser.getPassword());
                        newUser.setPassword(newPassword);

                        String query2 = "UPDATE oauth_users " +
                              "SET password = '" + newPassword +"' WHERE username = '" + currentUser.getUuid() + "'";
                        stmt.executeUpdate(query2);
                  }

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            currentUser.setName(newUser.getName());
            if(newUser.getPassword() != null && !newUser.getPassword().isEmpty()) {
                  currentUser.setPassword(newUser.getPassword());
            }
      }

      public void deleteUserById(String uuid) {
            /*Delete directory*/
            String query2;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "DELETE FROM Users WHERE uuid = '" + uuid + "'";
                  query2 = "DELETE FROM Images WHERE useruuid = '" + uuid + "'";
                  stmt.executeUpdate(query);
                  stmt.executeUpdate(query2);

                  String query3 = "DELETE FROM oauth_users WHERE username = '" + uuid + "'";
                  String query4 = "DELETE FROM oauth_user_authorities WHERE username = '" + uuid + "'";
                  stmt.executeUpdate(query3);
                  stmt.executeUpdate(query4);

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
      }

      public void deleteAllUsers(){
            List<User> users = findAllUsers();
            for(User u : users) {
                  deleteUserById(u.getUuid());
            }
      }

      public void addLinks(User user, HttpServletRequest req) {
            String uuid = user.getUuid();

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "UPDATE Users " +
                        "SET (selfLink, userslink, imageslink, uploadfolderlink, homelink) = ('" + getUriForSelf(user, req) +"', '" + getUriForUsers(req) +"', '" +
                        getUriForImages(req) +"', '" + getUriForUploadFolder(user, req) + "', '" + getUriForHome(req) + "') WHERE uuid = '" + uuid + "'";
                  stmt.executeUpdate(query);
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            user.addLink(getUriForHome(req), "home");
            user.addLink(getUriForSelf(user, req), "self");
            user.addLink(getUriForUsers(req), "users");
            user.addLink(getUriForImages(req), "images");
            user.addUploadFolderLink(getUriForUploadFolder(user, req), "upload_folder");
      }

      private String getUriForHome(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() +"/";
      }

      private String getUriForSelf(User user, HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/users/" + user.getUuid();
      }

      private String getUriForUsers(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/users/";
      }

      private String getUriForUploadFolder(User user, HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/images/" + user.getUuid();
      }

      private String getUriForImages(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/images/";
      }

      public boolean checkUserAuthentication(String u_uuid, String authHeader) {
            if(authHeader == null) {
                  return false;
            }
            boolean basic = authHeader.contains("Basic");
            if(! basic) {
                  return false;
            }
            String authToken = authHeader.replace("Basic ", "");
            byte[] credDecoded = Base64.getDecoder().decode(authToken);
            String credentials = new String(credDecoded, StandardCharsets.UTF_8);
            // credentials = username:password
            final String[] values = credentials.split(":", 2);
            final String[] requested = new String[2];

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT username,password FROM oauth_users WHERE username = '" + u_uuid +"'";
                  ResultSet res = stmt.executeQuery(query);
                  while (res.next()) {
                        requested[0] = res.getString("username");
                        requested[1] = res.getString("password");
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            //System.out.println("Requested: " + requested[0] + " " + requested[1]);
            //System.out.println("Found: " + values[0] + " " + values[1]);
            if(requested[0] == null || requested[1] == null) {
                  return false;
            }
            boolean userAuth = values[0].equals(requested[0]) && passwordEncoder.matches(values[1], requested[1]);
            return userAuth || checkAdminAuthentication(authHeader);
      }

      public boolean checkUserExistence(String authHeader) {
            if(authHeader == null) {
                  return false;
            }
            boolean basic = authHeader.contains("Basic");
            if(! basic) {
                  return false;
            }
            String authToken = authHeader.replace("Basic ", "");
            byte[] credDecoded = Base64.getDecoder().decode(authToken);
            String credentials = new String(credDecoded, StandardCharsets.UTF_8);
            // credentials = username:password
            final String[] values = credentials.split(":", 2);

            final List<Credential> dbCredentialsList = new ArrayList<>();

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT username,password FROM oauth_users";
                  ResultSet res = stmt.executeQuery(query);
                  while (res.next()) {
                        dbCredentialsList.add(new Credential(
                              res.getString("username"), res.getString("password")));
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            //System.out.println("Requested: " + requested[0] + " " + requested[1]);
            //System.out.println("Found: " + values[0] + " " + values[1]);

            for(Credential c : dbCredentialsList) {
                  if(values[0].equals(c.getUsername()) && passwordEncoder.matches(values[1], c.getPassword())) {
                        return true;
                  }
            }
            return false;
      }

      public boolean checkAdminAuthentication(String authHeader) {
            if(authHeader == null) {
                  return false;
            }
            boolean basic = authHeader.contains("Basic");
            if(! basic) {
                  return false;
            }
            String authToken = authHeader.replace("Basic ", "");
            byte[] credDecoded = Base64.getDecoder().decode(authToken);
            String credentials = new String(credDecoded, StandardCharsets.UTF_8);
            // credentials = username:password
            final String[] values = credentials.split(":", 2);
            final String[] requested = new String[3];

            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT username,password FROM oauth_users WHERE username = '" + values[0] +"' AND password = '" + values[1] + "'";
                  ResultSet res = stmt.executeQuery(query);
                  while (res.next()) {
                        requested[0] = res.getString("username");
                        requested[1] = res.getString("password");
                  }
                  res.close();

                  String query2 = "SELECT authority FROM oauth_user_authorities WHERE username = '" + values[0] + "'";
                  ResultSet res2 = stmt.executeQuery(query2);
                  while (res2.next()) {
                        requested[2] = res2.getString("authority");
                  }
                  res2.close();

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            //System.out.println("Requested: " + requested[0] + " " + requested[1]);
            //System.out.println("Found: " + values[0] + " " + values[1]);
            if(requested[0] == null || requested[1] == null || requested[2] == null) {
                  return false;
            }
            return requested[2].equals("ROLE_ADMIN") && values[0].equals(requested[0]) && passwordEncoder.matches(values[1], requested[1]);
      }

      private class Credential {
            private String username;
            private String password;

            private Credential(String username, String password) {
                  this.username = username;
                  this.password = password;
            }

            private String getUsername() {
                  return username;
            }

            private void setUsername(String username) {
                  this.username = username;
            }

            private String getPassword() {
                  return password;
            }

            private void setPassword(String password) {
                  this.password = password;
            }
      }
}
