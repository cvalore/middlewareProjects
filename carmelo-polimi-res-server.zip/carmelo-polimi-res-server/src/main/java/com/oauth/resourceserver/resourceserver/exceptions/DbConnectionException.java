package com.oauth.resourceserver.resourceserver.exceptions;

public class DbConnectionException extends RuntimeException {
      public DbConnectionException(String message) {
            super(message);
      }
}
