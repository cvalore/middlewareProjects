package com.oauth.resourceserver.resourceserver.service;

import com.oauth.resourceserver.resourceserver.exceptions.DataNotFoundException;
import com.oauth.resourceserver.resourceserver.exceptions.DbConnectionException;
import com.oauth.resourceserver.resourceserver.model.Database;
import com.oauth.resourceserver.resourceserver.model.Image;
import com.oauth.resourceserver.resourceserver.model.User;
import org.postgresql.util.PSQLException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service("imageService")
public class ImageServiceImpl implements ImageService{

      private Connection conn = null;
      private Statement stmt = null;
      private String query = null;

      public List<Image> findAllImages() {
            List<Image> images = new ArrayList<>();
            Image image = null;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT  imageuuid, title, width, height, homelink, selflink, userlink, userimageslink, imageslink, userslink FROM Images";
                  ResultSet res = stmt.executeQuery(query);
                  while(res.next()) {
                        image = new Image(res.getString("imageuuid"), res.getString("title"));
                        image.setWidth(res.getInt("width"));
                        image.setHeight(res.getInt("height"));
                        image.addLink(res.getString("homeLink"), "home");
                        image.addLink(res.getString("selfLink"), "self");
                        image.addLink(res.getString("usersLink"), "users");
                        image.addLink(res.getString("imagesLink"), "images");
                        image.addLink(res.getString("userlink"), "user");
                        image.addLink(res.getString("userimageslink"), "images_user");
                        images.add(image);
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            return images;
      }

      public List<Image> findByUserId(String uuid) {
            List<Image> images = new ArrayList<>();
            Image image;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT  imageuuid, title, width, height, homelink, selflink, userlink, userimageslink, imageslink, userslink FROM Images " +
                        "WHERE useruuid = '" + uuid + "'";
                  ResultSet res = stmt.executeQuery(query);
                  while(res.next()) {
                        image = new Image(res.getString("imageuuid"), res.getString("title"));
                        image.setWidth(res.getInt("width"));
                        image.setHeight(res.getInt("height"));
                        image.addLink(res.getString("homeLink"), "home");
                        image.addLink(res.getString("selfLink"), "self");
                        image.addLink(res.getString("usersLink"), "users");
                        image.addLink(res.getString("imagesLink"), "images");
                        image.addLink(res.getString("userlink"), "user");
                        image.addLink(res.getString("userimageslink"), "images_user");
                        images.add(image);
                  }
                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            return images;
      }

      public Image findByImageId(String u_uuid, String i_uuid) {
            Image image = null;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT  imageuuid, title, width, height, homelink, selflink, userlink, userimageslink, imageslink, userslink FROM Images " +
                        "WHERE useruuid = '" + u_uuid + "' AND imageuuid = '" + i_uuid + "'";
                  ResultSet res = stmt.executeQuery(query);
                  while(res.next()) {
                        image = new Image(res.getString("imageuuid"), res.getString("title"));
                        image.setWidth(res.getInt("width"));
                        image.setHeight(res.getInt("height"));
                        image.addLink(res.getString("homeLink"), "home");
                        image.addLink(res.getString("selfLink"), "self");
                        image.addLink(res.getString("usersLink"), "users");
                        image.addLink(res.getString("imagesLink"), "images");
                        image.addLink(res.getString("userlink"), "user");
                        image.addLink(res.getString("userimageslink"), "images_user");
                  }

                  res.close();
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }

            if(image == null) {
                  throw new DataNotFoundException("Image with uuid " + i_uuid + " not found");
            }
            return image;
      }

      public InputStream findByImageIdRaw(String u_uuid, String i_uuid) {
            InputStream inputStream = null;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  PreparedStatement ps = conn.prepareStatement("SELECT picture FROM images WHERE useruuid = ? AND imageuuid = ?");
                  ps.setString(1, u_uuid);
                  ps.setString(2, i_uuid);
                  ResultSet rs = ps.executeQuery();
                  while (rs.next()) {
                        inputStream = rs.getBinaryStream("picture");
                        // use the data in some way here
                  }
                  rs.close();
                  ps.close();
            } catch (SQLException e) {
                  if(e instanceof PSQLException) {
                        System.out.println("Error ");
                        System.out.println("-> " + e.getSQLState());
                        System.out.println("-> " + e.toString());
                        System.out.println("-> " + e.getErrorCode());
                        System.out.println("-> " + ((PSQLException) e).getServerErrorMessage());
                  }
                  e.printStackTrace();
            } finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            return inputStream;
      }

      public Image saveImage(MultipartFile file, String u_uuid) {
            String insertQuery;

            String i_uuid = UUID.randomUUID().toString().split("-")[0];

            Image image = new Image(file.getOriginalFilename());
            image.setUuid(i_uuid);

            //set height and width
            try {
                  setImageDim(file.getBytes(), image);
            } catch (IOException e) {
                  e.printStackTrace();
            }

            try {

                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  query = "SELECT * FROM Users WHERE uuid = '" + u_uuid + "'";
                  if (!stmt.execute(query)){
                        throw new DataNotFoundException("Specified user " + u_uuid + " is not present");
                  }

                  insertQuery = "INSERT INTO Images (useruuid, imageuuid, title, width, height, picture) VALUES (?, ?, ?, ?, ?, ?)";
                  PreparedStatement ps = conn.prepareStatement(insertQuery);
                  ps.setString(1, u_uuid);
                  ps.setString(2, i_uuid);
                  ps.setString(3, image.getTitle());
                  ps.setInt(4, image.getWidth());
                  ps.setInt(5, image.getHeight());
                  try {
                        ps.setBytes(6, file.getBytes());
                  } catch (IOException e) {
                        e.printStackTrace();
                  }

                  ps.executeUpdate();
                  ps.close();
            } catch (SQLException e) {
                  e.printStackTrace();
            }finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            return image;
      }

      public void updateImage(String userUuid, String imageUuid, String newTitle) {
            Image image = null;
            String selectQuery;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();
                  selectQuery = "SELECT  imageuuid, title, width, height, homelink, selflink, userlink, userimageslink, imageslink, userslink FROM Images " +
                        "WHERE useruuid = '" + userUuid + "' AND imageuuid = '" + imageUuid + "'";
                  ResultSet res = stmt.executeQuery(selectQuery);
                  while(res.next()) {
                        image = new Image(res.getString("imageuuid"), res.getString("title"));
                        image.setWidth(res.getInt("width"));
                        image.setHeight(res.getInt("height"));
                        image.addLink(res.getString("homeLink"), "home");
                        image.addLink(res.getString("selfLink"), "self");
                        image.addLink(res.getString("usersLink"), "users");
                        image.addLink(res.getString("imagesLink"), "images");
                        image.addLink(res.getString("userlink"), "user");
                        image.addLink(res.getString("userimageslink"), "images_user");
                  }
                  res.close();
                  query = "UPDATE Images " +
                        "SET title = '" + newTitle +"' WHERE useruuid = '" + userUuid + "' AND imageuuid = '" + imageUuid + "'";
                  stmt.executeUpdate(query);
            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
      }

      public void deleteImageById(String u_uuid, String i_uuid) {
            String deleteQuery;
            int removed = 0;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }

                  stmt = conn.createStatement();
                  deleteQuery = "DELETE FROM Images WHERE useruuid = '" + u_uuid + "' AND imageuuid = '" + i_uuid + "'";
                  removed = stmt.executeUpdate(deleteQuery);

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
      }

      public void deleteImagesByUser(String u_uuid) {
            String deleteImages;
            int deletedImagesNum = 0;
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }

                  stmt = conn.createStatement();
                  deleteImages = "DELETE FROM Images WHERE useruuid = '" + u_uuid + "'";
                  deletedImagesNum = stmt.executeUpdate(deleteImages);

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
      }

      public void deleteAllImages(List<User> users) {
            for(User u : users) {
                  deleteImagesByUser(u.getUuid());
            }
      }

      public void addLinks(Image image, String u_uuid, HttpServletRequest req) {
            try {
                  conn = Database.getConnection();
                  if(conn == null) {
                        throw new DbConnectionException("Cannot connect to db");
                  }
                  stmt = conn.createStatement();

                  query = "UPDATE Images " +
                        "SET (selflink, userslink, userlink, imageslink, userimageslink, homelink) = ('" + getUriForSelf(req, image, u_uuid) +"', '" + getUriForUsers(req) +"', '" +
                        getUriForUser(req, u_uuid) + "', '" + getUriForImages(req) +"', '" + getUriForImagesUser(req, u_uuid) + "', '" + getUriForHome(req) +"') " +
                        "WHERE useruuid = '" + u_uuid + "' AND imageuuid = '" + image.getUuid() + "'";
                  stmt.executeUpdate(query);

            } catch (SQLException e) {e.printStackTrace();}
            finally {
                  try {
                        if (stmt != null){
                              stmt.close();
                        }
                  } catch (SQLException e) {e.printStackTrace();}
                  try {
                        if (conn != null) {
                              conn.close();
                        }
                  } catch (SQLException e) {
                        e.printStackTrace();
                  }
            }
            image.addLink(getUriForHome(req), "home");
            image.addLink(getUriForSelf(req, image, u_uuid), "self");
            image.addLink(getUriForImagesUser(req, u_uuid), "images_user");
            image.addLink(getUriForImages(req), "images");
            image.addLink(getUriForUser(req, u_uuid), "user");
            image.addLink(getUriForUsers(req), "users");
      }

      private String getUriForHome(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/";
      }

      private String getUriForSelf(HttpServletRequest req, Image image, String userUuid) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/images/" + userUuid + "/" + image.getUuid();
      }

      private String getUriForUsers(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/users/";
      }

      private String getUriForUser(HttpServletRequest req, String userUuid) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/users/" + userUuid + "/";
      }

      private String getUriForImages(HttpServletRequest req) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/images/";
      }

      private String getUriForImagesUser(HttpServletRequest req, String userUuid) {
            return req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() +
                  req.getContextPath() + "/images/" + userUuid + "/";
      }

      private void setImageDim(byte[] imgByte, Image image) {

            try {
                  InputStream in = new ByteArrayInputStream(imgByte);
                  BufferedImage buf = ImageIO.read(in);
                  image.setHeight(buf.getHeight());
                  image.setWidth(buf.getWidth());
            } catch (IOException e) {
                  e.printStackTrace();
            }

      }
}
