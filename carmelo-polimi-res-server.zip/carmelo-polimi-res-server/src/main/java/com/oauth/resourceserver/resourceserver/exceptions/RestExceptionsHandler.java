package com.oauth.resourceserver.resourceserver.exceptions;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionsHandler extends ResponseEntityExceptionHandler {

      @ExceptionHandler(DbConnectionException.class)
      protected ResponseEntity<Object> handleDbConnectionError(DbConnectionException ex) {
            Error error = new Error(BAD_REQUEST);
            error.setMessage(ex.getMessage());
            return buildResponseEntity(error.getHtmlRepresentation(), error.getStatus());
      }

      @ExceptionHandler(DataNotFoundException.class)
      protected ResponseEntity<Object> handleDbConnectionError(DataNotFoundException ex) {
            Error error = new Error(NOT_FOUND);
            error.setMessage(ex.getMessage());
            return buildResponseEntity(error.getHtmlRepresentation(), error.getStatus());
      }

      private ResponseEntity<Object> buildResponseEntity(String error, HttpStatus status) {
            return new ResponseEntity<>(error, status);
      }
}
