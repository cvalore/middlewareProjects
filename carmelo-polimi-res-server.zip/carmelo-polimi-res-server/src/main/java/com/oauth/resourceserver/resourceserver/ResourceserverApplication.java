package com.oauth.resourceserver.resourceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Collections;

@SpringBootApplication
public class ResourceserverApplication {

	public static void main(String[] args) {
		System.setProperty("server.servlet.context-path", "/resserver/api");
		SpringApplication app = new SpringApplication(ResourceserverApplication.class);
		app.setDefaultProperties(Collections.singletonMap("server.port", "8080"));
		app.run(args);
	}

}
