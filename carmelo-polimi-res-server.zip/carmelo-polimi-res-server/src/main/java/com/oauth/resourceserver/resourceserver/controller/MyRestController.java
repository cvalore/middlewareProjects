package com.oauth.resourceserver.resourceserver.controller;

import com.oauth.resourceserver.resourceserver.frontend.HomeFrontend;
import com.oauth.resourceserver.resourceserver.frontend.ImageFrontend;
import com.oauth.resourceserver.resourceserver.frontend.UserFrontend;
import com.oauth.resourceserver.resourceserver.model.Image;
import com.oauth.resourceserver.resourceserver.model.User;
import com.oauth.resourceserver.resourceserver.service.AuthService;
import com.oauth.resourceserver.resourceserver.service.ImageService;
import com.oauth.resourceserver.resourceserver.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@RestController
public class MyRestController {

      private final UserService userService;  //Service which will do all data retrieval/manipulation work
      private final ImageService imageService;  //Service which will do all data retrieval/manipulation work
      private final AuthService authService;

      @Autowired
      public MyRestController(UserService userService, ImageService imageService, AuthService authService) {
            this.userService = userService;
            this.imageService = imageService;
            this.authService = authService;
      }

      //-------------------Home---------------------------------------------------------------------
      @RequestMapping(value = "/", method = RequestMethod.GET)
      public ResponseEntity<String> getHome() {
            return new ResponseEntity<>(HomeFrontend.getHomeRepresentation(), HttpStatus.OK);
      }


      /*@RequestMapping(value = "/login", method = RequestMethod.GET)
      public ResponseEntity<String> getLogin() {
            return new ResponseEntity<>(HomeFrontend.getLoginRepresentation(), HttpStatus.OK);
      }

      @RequestMapping(value = "/processLogin", method = RequestMethod.POST)
      public ResponseEntity<String> processLogin() {
            return new ResponseEntity<>("LOGGED IN - todo:insert home link", HttpStatus.OK);
      }

      @RequestMapping(value = "/failureLogin", method = RequestMethod.GET)
      public ResponseEntity<String> failureLogin() {
            return new ResponseEntity<>("ERROR WHILE LOGGING IN - todo:insert home link", HttpStatus.OK);
      }

      @RequestMapping(value = "/logout", method = RequestMethod.GET)
      public ResponseEntity<String> logout() {
            return new ResponseEntity<>("LOGGED OUT - todo:insert home link", HttpStatus.OK);
      }*/

      //-------------------Retrieve All Users--------------------------------------------------------

      @RequestMapping(value = "/users", method = RequestMethod.GET)
      public ResponseEntity<String> listAllUsers() {
            List<User> users = userService.findAllUsers();
            return new ResponseEntity<>(UserFrontend.getUsersRepresentation(users), HttpStatus.OK);
      }


      //-------------------Retrieve Single User--------------------------------------------------------

      @RequestMapping(value = "/users/{id}", method = RequestMethod.GET)
      public ResponseEntity<String> getUser(@PathVariable("id") String uuid) {
            System.out.println("Fetching User with uuid " + uuid);
            User user = userService.findById(uuid);
            if (user == null) {
                  System.out.println("User with uuid " + uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(UserFrontend.getUserRepresentation(user, "User requested"), HttpStatus.OK);
      }


      //-------------------Create a User--------------------------------------------------------

      @RequestMapping(value = "/users", method = RequestMethod.POST)
      public ResponseEntity<String> createUser(@RequestBody User user, UriComponentsBuilder ucBuilder, HttpServletRequest req) {
            System.out.println("Creating User " + user.getName());

            if(user.getName() == null || user.getName().isEmpty()) {
                  System.out.println("Name of the User not set");
                  return new ResponseEntity<>("Name of the User not set", HttpStatus.BAD_REQUEST);
            }

            if(user.getPassword() == null || user.getPassword().isEmpty()) {
                  return new ResponseEntity<>("Insert a valid passwordI", HttpStatus.BAD_REQUEST);
            }

            User savedUser = userService.saveUser(user);
            userService.addLinks(user, req);

            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getUuid()).toUri());
            return new ResponseEntity<>(UserFrontend.getUserRepresentation(savedUser, "User added"), headers, HttpStatus.CREATED);
      }


      @RequestMapping(value = "/users/raw_add/{cred}", method = RequestMethod.POST)
      public ResponseEntity<String> createUserRaw(@PathVariable("cred")String cred, UriComponentsBuilder ucBuilder, HttpServletRequest req) {
            String[] split = cred.split(":");
            if(split.length < 2 || split[0] == null || split[0].isEmpty() || split[1] == null || split[1].isEmpty()) {
                  return new ResponseEntity<>("Inserire Username:Password (username separated by a ':'(colon) from the password)", HttpStatus.BAD_REQUEST);
            }
            String name = split[0];
            String password = split[1];

            System.out.println("Creating User " + name);

            User user = new User("", name, password);
            User savedUser = userService.saveUser(user);
            userService.addLinks(user, req);

            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(ucBuilder.path("/user/" + user.getUuid()).build().toUri());
            return new ResponseEntity<>(UserFrontend.getUserRepresentation(savedUser, "User added"), headers, HttpStatus.CREATED);
      }


      //------------------- Update a User --------------------------------------------------------

      @RequestMapping(value = "/users/{id}", method = RequestMethod.PUT)
      public ResponseEntity<String> updateUser(@PathVariable("id") String uuid, @RequestBody User user,
                                               @RequestHeader(value = "authorization", required = false) String authHeader) {
            System.out.println("Updating User " + uuid);

            if(!userService.checkUserAuthentication(uuid, authHeader)) {
                  System.out.println("Not enough permissions to update the User with id " + uuid);
                  return new ResponseEntity<>("Not enough permissions to update the User with id " + uuid, HttpStatus.UNAUTHORIZED);
            }

            User currentUser = userService.findById(uuid);

            if (currentUser==null) {
                  System.out.println("User with id " + uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            if(user.getName() == null || user.getName().isEmpty()) {
                  System.out.println("Name of the User not set");
                  return new ResponseEntity<>("Name of the User not set", HttpStatus.BAD_REQUEST);
            }

            userService.updateUser(user, currentUser);

            return new ResponseEntity<>(UserFrontend.getUserRepresentation(currentUser, "User updated"), HttpStatus.OK);
      }

      //------------------- Delete a User --------------------------------------------------------

      @RequestMapping(value = "/users/{id}", method = RequestMethod.DELETE)
      public ResponseEntity<String> deleteUser(@PathVariable("id") String uuid,
                                               @RequestHeader(value = "authorization", required = false) String authHeader) {
            System.out.println("Fetching & Deleting User with id " + uuid);

            if(!userService.checkUserAuthentication(uuid, authHeader)) {
                  System.out.println("Not enough permissions to delete the User with id " + uuid);
                  return new ResponseEntity<>("Not enough permissions to delete the User with id " + uuid, HttpStatus.UNAUTHORIZED);
            }

            User user = userService.findById(uuid);
            if (user == null) {
                  System.out.println("Unable to delete. User with id " + uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            userService.deleteUserById(uuid);
            return new ResponseEntity<>(UserFrontend.getDeletedUserPage(), HttpStatus.OK);
      }


      //------------------- Delete All Users --------------------------------------------------------

      @RequestMapping(value = "/users", method = RequestMethod.DELETE)
      public ResponseEntity<String> deleteAllUsers(@RequestHeader(value = "authorization", required = false) String authHeader) {
            System.out.println("Deleting All Users");

            if(!userService.checkAdminAuthentication(authHeader)) {
                  System.out.println("Not enough permissions");
                  return new ResponseEntity<>("Not enough permissions", HttpStatus.UNAUTHORIZED);
            }

            userService.deleteAllUsers();
            return new ResponseEntity<>(UserFrontend.getDeletedUsersPage(), HttpStatus.OK);
      }


      //-------------------Retrieve All Images--------------------------------------------------------

      @RequestMapping(value = "/images", method = RequestMethod.GET)
      public ResponseEntity<String> listAllImages(
                  @RequestParam(value = "access_token", required = false) String accessToken,
                  @RequestParam(value = "client_id", required = false) String clientId,
                  @RequestParam(value = "client_secret", required = false) String clientSecret) {

            if(accessToken != null) {
                  if(clientId == null || clientSecret == null) {
                        System.out.println("Not enough permissions to get images");
                        return new ResponseEntity<>("Not enough permissions to get images", HttpStatus.UNAUTHORIZED);
                  }
                  boolean check = authService.checkToken(accessToken, clientId, clientSecret);
                  if(! check) {
                        System.out.println("Not enough permissions to get images");
                        return new ResponseEntity<>("Not enough permissions to get images", HttpStatus.UNAUTHORIZED);
                  }
            }

            List<Image> images = imageService.findAllImages();
            if(images.isEmpty()){
                  return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(ImageFrontend.getImagesRepresentation(images, "Images", "", accessToken), HttpStatus.OK);
      }


      //-------------------Retrieve All Images of a User--------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}", method = RequestMethod.GET)
      public ResponseEntity<String> getImagesOfUser(
                  @PathVariable("u_id") String u_uuid,
                  @RequestParam(value = "access_token", required = false) String accessToken) {

            System.out.println("Fetching Images of User with uuid " + u_uuid);
            List<Image> images = imageService.findByUserId(u_uuid);
            return new ResponseEntity<>(ImageFrontend.getImagesRepresentation(images, "Images requested", u_uuid, accessToken), HttpStatus.OK);
      }

      //-------------------Retrieve One Image of a User--------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}/{i_id}", method = RequestMethod.GET)
      public ResponseEntity<String> getImage(
                  @PathVariable("u_id") String u_uuid,
                  @PathVariable("i_id") String i_uuid,
                  @RequestParam(value = "access_token", required = false) String accessToken) {

            System.out.println("Fetching Image with uuid " + i_uuid + " of User with uuid " + u_uuid);
            Image image = imageService.findByImageId(u_uuid, i_uuid);
            if (image == null) {
                  System.out.println("Image with uuid " + i_uuid + " of User with uuid " + u_uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(ImageFrontend.getImageRepresentation(image, "Image requested", accessToken), HttpStatus.OK);
      }


      @RequestMapping(value = "/images/{u_id}/{i_id}/raw", method = RequestMethod.GET, produces = {MediaType.IMAGE_JPEG_VALUE})
      private @ResponseBody byte[] getImageRaw(@PathVariable("u_id") String u_uuid, @PathVariable("i_id") String i_uuid,
                                              @RequestHeader(name="access_token", required = false) String accessToken) {

            System.out.println("Fetching Image with uuid " + i_uuid + " of User with uuid " + u_uuid);
            InputStream image = imageService.findByImageIdRaw(u_uuid, i_uuid);
            if (image == null) {
                  System.out.println("Image with uuid " + i_uuid + " of User with uuid " + u_uuid + " not found");
                  //return new ResponseEntity<>(HttpStatus.NOT_FOUND);
                  return null;
            }
            //return new ResponseEntity<>(image, HttpStatus.OK);
            try {
                  return toByteArray(image);
            } catch (IOException e) {
                  e.printStackTrace();
            }
            return null;
      }


      //-------------------Create a Image--------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}", method = RequestMethod.POST, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
      public ResponseEntity<String> createImage(@PathVariable("u_id") String u_uuid, @RequestParam MultipartFile file, UriComponentsBuilder ucBuilder, HttpServletRequest req,
                                                @RequestHeader(name="authorization", required = false) String authHeader) {

            if(!userService.checkUserAuthentication(u_uuid, authHeader)) {
                  System.out.println("Not enough permissions to update the User with id " + u_uuid);
                  return new ResponseEntity<>("Not enough permissions to update the User with id " + u_uuid, HttpStatus.UNAUTHORIZED);
            }

            System.out.println("Loading Image of User " + u_uuid);

            Image image = imageService.saveImage(file, u_uuid);
            imageService.addLinks(image, u_uuid, req);

            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(ucBuilder.path("/images/"+u_uuid+"/{i_id}").buildAndExpand(image.getUuid()).toUri());
            return new ResponseEntity<>(ImageFrontend.getImageRepresentation(image, "Image uploaded", null), headers, HttpStatus.CREATED);
      }


      //------------------- Update a Image --------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}/{i_id}", method = RequestMethod.PUT)
      public ResponseEntity<String> updateImage(@PathVariable("u_id") String u_uuid, @PathVariable("i_id") String i_uuid,
                                                @RequestBody Image image,
                                                @RequestHeader(name="authorization", required = false) String authHeader) {

            if(!userService.checkUserAuthentication(u_uuid, authHeader)) {
                  System.out.println("Not enough permissions to update the User with id " + u_uuid);
                  return new ResponseEntity<>("Not enough permissions to update the User with id " + u_uuid, HttpStatus.UNAUTHORIZED);
            }

            System.out.println("Updating Image " + i_uuid + " of User " + u_uuid);

            Image currentImage = imageService.findByImageId(u_uuid, i_uuid);

            if (currentImage==null) {
                  System.out.println("Image with id " + i_uuid + " of User with id " + u_uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            currentImage.setTitle(image.getTitle());

            imageService.updateImage(u_uuid, i_uuid, image.getTitle());

            return new ResponseEntity<>(ImageFrontend.getImageRepresentation(currentImage, "Image renamed", null), HttpStatus.OK);
      }

      //------------------- Delete a Image --------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}/{i_id}", method = RequestMethod.DELETE)
      public ResponseEntity<String> deleteImage(@PathVariable("u_id") String u_uuid, @PathVariable("i_id") String i_uuid,
                                                @RequestHeader(value = "authorization", required = false) String authHeader) {

            if(!userService.checkUserAuthentication(u_uuid, authHeader)) {
                  System.out.println("Not enough permissions to update the User with id " + u_uuid);
                  return new ResponseEntity<>("Not enough permissions to update the User with id " + u_uuid, HttpStatus.UNAUTHORIZED);
            }

            System.out.println("Fetching & Deleting Image with id " + i_uuid + " of User with id " + u_uuid);

            Image image = imageService.findByImageId(u_uuid, i_uuid);
            if (image == null) {
                  System.out.println("Unable to delete. Image with id " + i_uuid + " of User with id " + u_uuid + " not found");
                  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            imageService.deleteImageById(u_uuid, i_uuid);
            return new ResponseEntity<>(ImageFrontend.getDeletedImage(), HttpStatus.OK);
      }


      //------------------- Delete All Images of a User --------------------------------------------------------

      @RequestMapping(value = "/images/{u_id}", method = RequestMethod.DELETE)
      public ResponseEntity<String> deleteAllImagesOfUser(@PathVariable("u_id") String u_uuid,
                                                          @RequestHeader(value = "authorization", required = false) String authHeader) {

            if(!userService.checkUserAuthentication(u_uuid, authHeader)) {
                  System.out.println("Not enough permissions to update the User with id " + u_uuid);
                  return new ResponseEntity<>("Not enough permissions to update the User with id " + u_uuid, HttpStatus.UNAUTHORIZED);
            }


            System.out.println("Deleting All Images of user with id " + u_uuid);

            imageService.deleteImagesByUser(u_uuid);
            return new ResponseEntity<>(ImageFrontend.getDeletedImages(), HttpStatus.OK);
      }

      //------------------- Delete All Images --------------------------------------------------------

      @RequestMapping(value = "/images", method = RequestMethod.DELETE)
      public ResponseEntity<String> deleteAllImages(@RequestHeader(value = "authorization", required = false) String authHeader) {

            if(!userService.checkAdminAuthentication(authHeader)) {
                  System.out.println("Not enough permissions");
                  return new ResponseEntity<>("Not enough permissions", HttpStatus.UNAUTHORIZED);
            }

            System.out.println("Deleting All Images");

            imageService.deleteAllImages(userService.findAllUsers());
            return new ResponseEntity<>(ImageFrontend.getDeletedImagesAll(), HttpStatus.OK);
      }


      private byte[] toByteArray(InputStream in) throws IOException {

            ByteArrayOutputStream os = new ByteArrayOutputStream();

            byte[] buffer = new byte[1024];
            int len;

            // read bytes from the input stream and store them in buffer
            while ((len = in.read(buffer)) != -1) {
                  // write bytes from the buffer into output stream
                  os.write(buffer, 0, len);
            }

            return os.toByteArray();
      }
}