package com.oauth.resourceserver.resourceserver.service;


import com.oauth.resourceserver.resourceserver.model.User;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface UserService {

      User findById(String uuid);

      User saveUser(User user);

      void updateUser(User newUser, User currentUser);

      void deleteUserById(String uuid);

      List<User> findAllUsers();

      void deleteAllUsers();

      void addLinks(User user, HttpServletRequest req);

      boolean checkUserAuthentication(String u_uuid, String authHeader);

      boolean checkAdminAuthentication(String authHeader);

      boolean checkUserExistence(String authHeader);
}
