package com.oauth.resourceserver.resourceserver.service;

public interface AuthService {
      boolean checkToken(String accessToken, String clientId, String clientSecret);
}
