package com.oauth.resourceserver.resourceserver.frontend;


import com.oauth.resourceserver.resourceserver.model.Link;

public class LinkFrontend {
      public static String getLinkRepresentation(Link l) {
            return "<a href=\"" + l.getLink() + "\"> " + l.getRel() + "</a>" + "  " + l.getLink() + "<br>";
      }
}
