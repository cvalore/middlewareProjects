package com.oauth.resourceserver.resourceserver.frontend;

public class HomeFrontend {

      public static String getHomeRepresentation() {
            return "<!DOCTYPE html>\n" +
                        "<html>\n" +
                        "\n" +
                        "<head>\n" +
                        "    <meta charset=\"UTF-8\">\n" +
                        "    <title>Image Server RESTful API service</title>\n" +
                        "</head>\n" +
                        "\n" +
                        "<body>\n" +
                        "\n" +
                        "<h1>\n" +
                        "    Image Server RESTful API service\n" +
                        "</h1>\n" +
                        "\n" +
                        "<h2>\n" +
                        "    Goes to <a id = \"myLink\" href=\"\">  ../api/users/  </a> to see all the Users in the system <br>\n" +
                        "</h2>\n" +
                        "\n" +
                        "<h2>\n" +
                        "    <br>Use the form below to register a new User in the system\n" +
                        "</h2>\n" +
                        "\n" +
                        "<h3> Insert name and password of the User to create </h3>\n" +
                        "\n" +
                        "<form id =\"formInsert\" method=\"post\" enctype=\"text/plain\" onsubmit=\"insertFunction()\">\n" +
                        "    <label>\n" +
                        "        Insert name and password ( separated by ':'(colon) )\n" +
                        "        <input type=\"text\" name=\"nameInsert\">\n" +
                        "    </label>\n" +
                        "    <input type=\"submit\" value=\"Create it\">\n" +
                        "</form>\n" +
                        "\n" +
                        "<script>\n" +
                        "    function insertFunction(){\n" +
                        "        var action_src = window.location.href + \"users/raw_add/\" + document.getElementsByName(\"nameInsert\")[0].value;\n" +
                        "        var my_form = document.getElementById('formInsert');\n" +
                        "        my_form.action = action_src ;\n" +
                        "    }\n" +
                        "</script>\n" +
                        "\n" +
                        "<script>\n" +
                        "    var linkSection = document.getElementById(\"myLink\");\n" +
                        "    linkSection.href = window.location.href + \"users/\";\n" +
                        "</script>\n" +
                        "\n" +
                        "</body>\n" +
                        "\n" +
                        "</html>";
      }

      public static String getLoginRepresentation() {
            return "<html>\n" +
                        "<head></head>\n" +
                        "<body>\n" +
                        "   <h1>Login</h1>\n" +
                        "   <form name='f' action=\"/resserver/api/processLogin\" method='POST'>\n" +
                        "      <table>\n" +
                        "         <tr>\n" +
                        "            <td>User:</td>\n" +
                        "            <td><input type='text' name='username' value=''></td>\n" +
                        "         </tr>\n" +
                        "         <tr>\n" +
                        "            <td>Password:</td>\n" +
                        "            <td><input type='password' name='password' /></td>\n" +
                        "         </tr>\n" +
                        "         <tr>\n" +
                        "            <td><input name=\"submit\" type=\"submit\" value=\"submit\" /></td>\n" +
                        "         </tr>\n" +
                        "      </table>\n" +
                        "  </form>\n" +
                        "</body>\n" +
                        "</html>";
      }
}
